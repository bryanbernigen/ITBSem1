#NIM/Nama : 16520237/Bryan Bernigen
#Tanggal  : Minggu, 18 Oktober 2020
#Deskripsi: Program Print 'Hello, World!'

print('Hello, World!')