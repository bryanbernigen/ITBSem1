#NIM/Nama : 16520237/Bryan Bernigen
#Tanggal  : Minggu, 1 November 2020
#Deskripsi: Print angka sebanyak n kali

#kamus
#n: integer

n= int(input('Masukkan jumlah angka: '))
for i in range(1,n+1):
    print(i,' ' ,end='')